#include<stdio.h>

void solve(){
	printf("%d",9/2);
	printf("%f",9.0/2);
}
int main(){
	solve();
	return 0;
}
