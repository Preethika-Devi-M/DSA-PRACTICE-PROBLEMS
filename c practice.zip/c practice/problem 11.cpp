#include<stdio.h>

void solve(){
	bool ok = false;
	printf(ok?"yes":"no");
}
int main(){
	solve();
	return 0;
}
