#include<stdio.h>

void solve(){
	int x = printf("Hello");
	printf("%d",x);
}
int main(){
	solve();
	return 0;
}
