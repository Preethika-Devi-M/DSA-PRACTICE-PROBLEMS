#include<stdio.h>
#define VAL 3*(2+6)
void solve(){
	int a = 10+VAL;
	printf("%d",a);
}
int main(){
	solve();
	return 0;
}
